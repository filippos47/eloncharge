def usermod(args):
    print("usermod")

def users(args):
    print("users")

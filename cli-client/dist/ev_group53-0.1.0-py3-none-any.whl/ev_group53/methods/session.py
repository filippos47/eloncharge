def login(args):
    print("login")

def logout(args):
    print("logout")

def sessions_per_point(args):
    print("sessions_per_point")

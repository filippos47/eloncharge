def sessions_per_station(args):
    print("sessions_per_station")

def healthcheck(args):
    print("healthcheck")

def sessionupd(args):
    print("sessionupd")

def resetsessions(args):
    print("resetsessions")
